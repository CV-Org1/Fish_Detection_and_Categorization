# Fish-Dataset > 2024-05-30 3:51pm
https://universe.roboflow.com/fishes/fish-dataset-8co94

Provided by a Roboflow user
License: CC BY 4.0

